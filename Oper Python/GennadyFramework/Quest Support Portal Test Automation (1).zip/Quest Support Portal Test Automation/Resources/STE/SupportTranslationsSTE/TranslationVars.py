# coding=UTF-8 
'''
Created on 02 ���. 2016 �.

@author: gborodin
'''
import xml.etree.ElementTree as ET
import os
print os.getcwd()

# tree = None

# tree = ET.parse('../TranslationExport_Eng.ste', parser=None)

def get_variables(arg):
    if arg == 'en-us':
        tree = ET.parse('./Resources/STE/TranslationExport_Eng.ste', parser=None)
    elif arg == 'ja-jp':
        tree = ET.parse('./Resources/STE/TranslationExport_Japan.ste', parser=None)
    elif arg == 'es-es':
        tree = ET.parse('./Resources/STE/TranslationExport_Spain.ste', parser=None)
    return _parseSteTree(tree)


def _parseSteTree(steTree):
    steVars = dict()
    
    root = steTree.getroot()
    
    for child in root:
        ste_text = ''
        if child.text == None:
            ste_text = ''
        else:
            ste_text = child.text
        steVars.update({child.attrib['key']:ste_text.strip()})
    
    return steVars    
    